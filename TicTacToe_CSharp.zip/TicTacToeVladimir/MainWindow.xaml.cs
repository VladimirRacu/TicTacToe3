﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace TicTacToe
{

    enum CellState { Empty, X, O }
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        static int rows = 3, cols = 3;
        Button[,] buttonBoard = new Button[rows, cols];
        CellState[,] board = new CellState[3, 3];
        Random random = new Random();
        bool firstPlayerMove;                            // true - means first player move, false - it's time of second player
        bool gameEnd = false;
        int winner = 0;
        bool oPCplayer = false, xPCplayer = false;
        int[,] array = new int[,] { { 0, 0, 0 }, { 0, 0, 0 }, { 0, 0, 0 } };

        public void leftPCplayerFunction()
        {
            if (!xPCplayer)
            {
                if (oPCplayer)
                {
                    firstGamerName.Text = "";
                    leftPCplayer.Foreground = Brushes.Azure;
                    oPCplayer = false;
                }
                else
                {
                    firstGamerName.Text = "O - PC player";
                    leftPCplayer.Foreground = Brushes.Yellow;
                    oPCplayer = true;
                }
            }
        }

        public void rightPCplayerFunction()
        {
            if (!oPCplayer)
            {
                if (xPCplayer)
                {
                    secondGamerName.Text = "";
                    rightPCplayer.Foreground = Brushes.Azure;
                    xPCplayer = false;
                }
                else
                {
                    secondGamerName.Text = "X - PC player";
                    rightPCplayer.Foreground = Brushes.Yellow;
                    xPCplayer = true;
                }
            }
        }


        int turnCount;

        private void resetGame()
        {
            turnCount = 0;
            for (int row = 0; row < 3; row++)
            {
                for (int col = 0; col < 3; col++)
                {
                    board[row, col] = CellState.Empty;
                    buttonBoard[row, col].Content = "";
                    Button buttonNumber = (Button)this.FindName("Bt" + row.ToString() + col.ToString());
                    buttonNumber.IsEnabled = true;
                }
            }
        }

        private void clicked(int row, int col)
        {
            if (firstPlayerMove)
            {
                array[row, col] = 1;
                board[row, col] = CellState.O;
                buttonBoard[row, col].Content = "O";
                left_player.Background = Brushes.Azure;
                right_player.Background = Brushes.Blue;
                //System.Reflection.AssemblyKeyNameAttribute buttonNumber = this.GetType().GetField("variable" + row.ToString() + col.ToString());
                //ProgressBar buttonNumber = (ProgressBar)this.Controls["Bt" + row.ToString() + col.ToString()];
                Button buttonNumber = (Button)this.FindName("Bt" + row.ToString() + col.ToString());
                buttonNumber.IsEnabled = false; //arrayButtons[row,col].disabled=true;
                firstPlayerMove = false;
                checkWin();
                if (xPCplayer && !gameEnd)
                {
                    if (!firstPlayerMove) { checkState(10); }
                }
            }
            else
            {
                array[row, col] = 10;
                board[row, col] = CellState.X;
                buttonBoard[row, col].Content = "X";
                left_player.Background = Brushes.Red;
                right_player.Background = Brushes.Azure;
                //ProgressBar bar = (ProgressBar)this.Controls["Bt" + row.ToString() + col.ToString()];
                Button buttonNumber = (Button)this.FindName("Bt" + row.ToString() + col.ToString());
                buttonNumber.IsEnabled = false; //arrayButtons[row,col].disabled=true;
                firstPlayerMove = true;
                checkWin();
                if (oPCplayer && !gameEnd)
                {
                    if (firstPlayerMove) { checkState(1); }
                }
            }
        }

        public void checkWin()
        {
            var check = 0;
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                {
                    if (array[i, j] == 0)
                    {
                        check++;
                    }
                }
            }
            ////////////////////////////////////////////////////////////////

            // check if winner exists and background images for winning line are changed accordingly
            if (check != 0)
            {
                for (int i = 0; i < rows; i++)
                {
                    if (array[i, 0] == 1 && array[i, 1] == 1 && array[i, 2] == 1)
                    {
                        winner = 1;
                        gameEnd = true;
                    }
                    if (array[i, 0] == 10 && array[i, 1] == 10 && array[i, 2] == 10)
                    {
                        winner = 2;
                        gameEnd = true;
                    }
                }
                for (int j = 0; j < cols; j++)
                {
                    if (array[0, j] == 1 && array[1, j] == 1 && array[2, j] == 1)
                    {
                        winner = 1;
                        gameEnd = true;
                    }
                    if (array[0, j] == 10 && array[1, j] == 10 && array[2, j] == 10)
                    {
                        winner = 2;
                        gameEnd = true;
                    }
                }
                if (array[0, 0] == 1 && array[1, 1] == 1 && array[2, 2] == 1)
                {
                    winner = 1;
                    gameEnd = true;
                }
                if (array[0, 0] == 10 && array[1, 1] == 10 && array[2, 2] == 10)
                {
                    winner = 2;
                    gameEnd = true;
                }
                if (array[0, 2] == 1 && array[1, 1] == 1 && array[2, 0] == 1)
                {
                    winner = 1;
                    gameEnd = true;
                }
                if (array[0, 2] == 10 && array[1, 1] == 10 && array[2, 0] == 10)
                {
                    winner = 2;
                    gameEnd = true;
                }
                ////////////////////////////////////////////////////////////

                // if game ends:
                if (gameEnd)
                {
                    // disable all not pushed cells
                    finish();
                    if (winner == 1)
                    {
                        MessageBox.Show("Player " + firstGamerName.Text + " won!");
                    }
                    else
                    {
                        MessageBox.Show("Player " + secondGamerName.Text + " won!");
                    }
                }///////////////////////////////////////////////////////////
            }
            else
            {
                // display message if is draw result
                MessageBox.Show("Game over with draw!");
            }///////////////////////////////////////////////////////////////
        }

        private void finish()
        {
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                {
                    if (array[i, j] == 0)
                    {
                        //ProgressBar bar = (ProgressBar)this.Controls["Bt" + i.ToString() + j.ToString()];
                        Button buttonNumber = (Button)this.FindName("Bt" + i.ToString() + j.ToString());
                        buttonNumber.IsEnabled = false; //arrayButtons[i,j].disabled=true;
                    }
                }
            }
        }


        private void checkState(int num)
        {
            // if game just began PC push central button = [1,1]
            if (array[1, 1] == 0)
            {
                clicked(1, 1);
            }
            else
            {
                // if central button was pushed, PC select one from all free corners
                if (((array[0, 0] + array[0, 2] + array[2, 0] + array[2, 2]) == 0)
                     &&
                     (
                        ((array[0, 1] + array[1, 0] + array[1, 2] + array[2, 1]) == 0)
                        ||
                        (// if central button was pushed by PC and another player selected two opposite sides, PC select one from all free corners
                            (((array[0, 1] + array[2, 1] == 2) || (array[1, 0] + array[1, 2] == 2))
                             && (array[1, 1] == 10)
                             && ((array[0, 1] + array[1, 2] + array[2, 1] + array[1, 0]) == 2))
                             ||
                             (((array[0, 1] + array[2, 1] == 20) || (array[1, 0] + array[1, 2] == 20))
                             && (array[1, 1] == 1)
                             && ((array[0, 1] + array[1, 2] + array[2, 1] + array[1, 0]) == 20))
                        )
                     )
                   )
                {
                    int corner = random.Next(1, 4);
                    switch (corner)
                    {
                        case 1: if (array[0, 0] == 0) { clicked(0, 0); }; break;
                        case 2: if (array[0, 2] == 0) { clicked(0, 2); }; break;
                        case 3: if (array[2, 2] == 0) { clicked(2, 2); }; break;
                        case 4: if (array[2, 0] == 0) { clicked(2, 0); }; break;
                    }
                }
                else
                {
                    if (// check if one side was pushed by another player and select one corner
                            (((array[0, 1] + array[1, 2] + array[2, 1] + array[1, 0]) == 1)
                                || ((array[0, 1] + array[1, 2] + array[2, 1] + array[1, 0]) == 10))
                            && ((array[0, 0] + array[0, 2] + array[2, 0] + array[2, 2]) == 0)
                        )
                    {
                        if ((array[1, 0] + array[0, 1] != 0) && (array[2, 2] == 0)) { clicked(2, 2); }
                        else
                            if ((array[0, 1] + array[1, 2] != 0) && (array[2, 0] == 0)) { clicked(2, 0); }
                            else
                                if ((array[2, 1] + array[1, 2] != 0) && (array[0, 0] == 0)) { clicked(0, 0); }
                                else
                                    if ((array[2, 1] + array[1, 0] != 0) && (array[0, 2] == 0)) { clicked(0, 2); }
                    }
                    else
                    {
                        if (
                                (// check if only one corner was pushed and select another one 
                                    (((array[0, 0] + array[0, 2] + array[2, 0] + array[2, 2]) == 1)
                                        || ((array[0, 0] + array[0, 2] + array[2, 0] + array[2, 2]) == 10))
                                    && ((array[0, 1] + array[1, 2] + array[2, 1] + array[1, 0]) == 0)
                                )
                                ||
                                (// check if one side and one opposite corner were pushed by another player and select another one
                                    (
                                        (((array[0, 0] == 1) && (array[1, 2] + array[2, 1] == 1)) ||
                                        ((array[0, 2] == 1) && (array[1, 0] + array[2, 1] == 1)) ||
                                        ((array[2, 2] == 1) && (array[1, 0] + array[0, 1] == 1)) ||
                                        ((array[2, 0] == 1) && (array[0, 1] + array[1, 2] == 1)))
                                        && (array[1, 1] == 10)
                                        && ((array[0, 0] + array[0, 2] + array[2, 0] + array[2, 2]) == 1)
                                    )
                                    ||
                                    (
                                        (((array[0, 0] == 10) && (array[1, 2] + array[2, 1] == 10)) ||
                                        ((array[0, 2] == 10) && (array[1, 0] + array[2, 1] == 10)) ||
                                        ((array[2, 2] == 10) && (array[1, 0] + array[0, 1] == 10)) ||
                                        ((array[2, 0] == 10) && (array[0, 1] + array[1, 2] == 10)))
                                        && (array[1, 1] == 1)
                                        && ((array[0, 0] + array[0, 2] + array[2, 0] + array[2, 2]) == 10)
                                    )
                                )
                            )
                        {
                            if ((array[0, 0] != 0) && (array[2, 2] == 0)) { clicked(2, 2); }
                            else
                                if ((array[0, 2] != 0) && (array[2, 0] == 0)) { clicked(2, 0); }
                                else
                                    if ((array[2, 0] != 0) && (array[0, 2] == 0)) { clicked(0, 2); }
                                    else
                                        if ((array[2, 2] != 0) && (array[0, 0] == 0)) { clicked(0, 0); }
                        }
                        else
                        {
                            // check if two nearest sides were pushed by another player and select corner between them
                            if ((((array[0, 1] + array[1, 2] + array[2, 1] + array[1, 0]) == 2)
                                    || ((array[0, 1] + array[1, 2] + array[2, 1] + array[1, 0]) == 20))
                                    && ((array[0, 0] + array[0, 2] + array[2, 0] + array[2, 2]) == 0))
                            {
                                if ((array[1, 0] != 0) && (array[0, 1] != 0) && (array[0, 0] == 0)) { clicked(0, 0); }
                                else
                                    if ((array[0, 1] != 0) && (array[1, 2] != 0) && (array[0, 2] == 0)) { clicked(0, 2); }
                                    else
                                        if ((array[2, 1] != 0) && (array[1, 2] != 0) && (array[2, 2] == 0)) { clicked(2, 2); }
                                        else
                                            if ((array[2, 1] != 0) && (array[1, 0] != 0) && (array[2, 0] == 0)) { clicked(2, 0); }
                            }
                            else
                            {
                                if (// check if two opposite corner were pushed by another player and choose one cell on side part near any selected corner
                                    // note that selection of new corner lead to loose
                                        (
                                            (((array[0, 0] == 1) && (array[2, 2] == 1)) || ((array[2, 0] == 1) && (array[0, 2] == 1)))
                                            && (array[1, 1] == 10)
                                            && ((array[0, 1] + array[1, 2] + array[2, 1] + array[1, 0]) == 0)
                                        )
                                        ||
                                        (
                                            (((array[0, 0] == 10) && (array[2, 2] == 10)) || ((array[2, 0] == 10) && (array[0, 2] == 10)))
                                            && (array[1, 1] == 1)
                                            && ((array[0, 1] + array[1, 2] + array[2, 1] + array[1, 0]) == 0)
                                        )
                                    )
                                {
                                    int side = random.Next(1, 4);
                                    switch (side)
                                    {
                                        case 1: if (array[0, 1] == 0) { clicked(0, 1); }; break;
                                        case 2: if (array[1, 0] == 0) { clicked(1, 0); }; break;
                                        case 3: if (array[1, 2] == 0) { clicked(1, 2); }; break;
                                        case 4: if (array[2, 1] == 0) { clicked(2, 1); }; break;
                                    }
                                }
                                else
                                {
                                    // check all states when 2 cells pushed by non-PC player could lead to win and block them
                                    if (checkPCTwoCells(num)) { return; }
                                    else
                                    {
                                        // check all states when 2 cells pushed by PC could lead to win
                                        if (checkNonPCTwoCells(num)) { return; }
                                        else
                                        {
                                            // check if 2 (O + O) or (X + X) or (O + X) corners were pushed and select another one
                                            if (((array[0, 0] + array[0, 2] + array[2, 0] + array[2, 2]) == 2)
                                                    || ((array[0, 0] + array[0, 2] + array[2, 0] + array[2, 2]) == 20)
                                                    || ((array[0, 0] + array[0, 2] + array[2, 0] + array[2, 2]) == 11))
                                            {
                                                int goal = random.Next(0, 1);
                                                if (goal == 1)
                                                {
                                                    if (array[0, 0] == 0) { clicked(0, 0); }
                                                    else
                                                        if (array[0, 2] == 0) { clicked(0, 2); }
                                                        else
                                                            if (array[2, 0] == 0) { clicked(2, 0); }
                                                            else if (array[2, 2] == 0) { clicked(2, 2); }
                                                }
                                                else
                                                {// available variants: could be free only ( 0x0 and 2x2 ) or ( 0x2 and 2x0 )
                                                    if (array[0, 0] == 0)
                                                    {
                                                        if (array[2, 2] == 0) { clicked(2, 2); }
                                                    }
                                                    else
                                                        if (array[0, 2] == 0)
                                                        {
                                                            if (array[2, 0] == 0) { clicked(2, 0); }
                                                        }
                                                }
                                            }
                                            else
                                            {
                                                // check if 3 (O + O + X)or(O + X + X) corners were pushed and select another one
                                                if (((array[0, 0] + array[0, 2] + array[2, 0] + array[2, 2]) == 12)
                                                        || ((array[0, 0] + array[0, 2] + array[2, 0] + array[2, 2]) == 21))
                                                {
                                                    if (array[0, 0] == 0) { clicked(0, 0); }
                                                    else
                                                        if (array[0, 2] == 0) { clicked(0, 2); }
                                                        else
                                                            if (array[2, 0] == 0) { clicked(2, 0); }
                                                            else if (array[2, 2] == 0) { clicked(2, 2); }
                                                }
                                                else
                                                {
                                                    int check = 0, row_temp = 0, col_temp = 0;
                                                    for (int i = 0; i < rows; i++)
                                                    {
                                                        for (int j = 0; j < cols; j++)
                                                        {
                                                            if (array[i, j] == 0)
                                                            {
                                                                check++;
                                                                row_temp = i;
                                                                col_temp = j;
                                                            }
                                                        }
                                                    }
                                                    if (check == 2) // if two cells are free and no one strategy were applied, any free cell is selected by PC
                                                    {
                                                        if (array[row_temp, col_temp] == 0) { clicked(row_temp, col_temp); }
                                                    }
                                                    if (check == 1) // if only one cells is not pushed, it is selected by PC
                                                    {
                                                        if (array[row_temp, col_temp] == 0) { clicked(row_temp, col_temp); }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // check all states when 2 cells pushed by PC could lead to win
        private bool checkPCTwoCells(int num)
        {
            if ((array[0, 0] == array[0, 1]) && (array[0, 1] == num) && (array[0, 2] == 0)) { clicked(0, 2); return true; }
            if ((array[0, 0] == array[0, 2]) && (array[0, 2] == num) && (array[0, 1] == 0)) { clicked(0, 1); return true; }
            if ((array[0, 0] == array[1, 0]) && (array[1, 0] == num) && (array[2, 0] == 0)) { clicked(2, 0); return true; }
            if ((array[0, 0] == array[1, 1]) && (array[1, 1] == num) && (array[2, 2] == 0)) { clicked(2, 2); return true; }
            if ((array[0, 0] == array[2, 0]) && (array[2, 0] == num) && (array[1, 0] == 0)) { clicked(1, 0); return true; }
            if ((array[0, 0] == array[2, 2]) && (array[2, 2] == num) && (array[1, 1] == 0)) { clicked(1, 1); return true; }
            if ((array[0, 1] == array[0, 2]) && (array[0, 2] == num) && (array[0, 0] == 0)) { clicked(0, 0); return true; }
            if ((array[0, 1] == array[1, 1]) && (array[1, 1] == num) && (array[2, 1] == 0)) { clicked(2, 1); return true; }
            if ((array[0, 1] == array[2, 1]) && (array[2, 1] == num) && (array[1, 1] == 0)) { clicked(1, 1); return true; }
            if ((array[0, 2] == array[1, 1]) && (array[1, 1] == num) && (array[2, 0] == 0)) { clicked(2, 0); return true; }
            if ((array[0, 2] == array[1, 2]) && (array[1, 2] == num) && (array[2, 2] == 0)) { clicked(2, 2); return true; }
            if ((array[0, 2] == array[2, 0]) && (array[2, 0] == num) && (array[1, 1] == 0)) { clicked(1, 1); return true; }
            if ((array[0, 2] == array[2, 2]) && (array[2, 2] == num) && (array[1, 2] == 0)) { clicked(1, 2); return true; }
            if ((array[1, 0] == array[1, 1]) && (array[1, 1] == num) && (array[1, 2] == 0)) { clicked(1, 2); return true; }
            if ((array[1, 0] == array[1, 2]) && (array[1, 2] == num) && (array[1, 1] == 0)) { clicked(1, 1); return true; }
            if ((array[1, 0] == array[2, 0]) && (array[2, 0] == num) && (array[0, 0] == 0)) { clicked(0, 0); return true; }
            if ((array[1, 1] == array[1, 2]) && (array[1, 2] == num) && (array[1, 0] == 0)) { clicked(1, 0); return true; }
            if ((array[1, 1] == array[2, 0]) && (array[2, 0] == num) && (array[0, 2] == 0)) { clicked(0, 2); return true; }
            if ((array[1, 1] == array[2, 1]) && (array[2, 1] == num) && (array[0, 1] == 0)) { clicked(0, 1); return true; }
            if ((array[1, 1] == array[2, 2]) && (array[2, 2] == num) && (array[0, 0] == 0)) { clicked(0, 0); return true; }
            if ((array[1, 2] == array[2, 2]) && (array[2, 2] == num) && (array[0, 2] == 0)) { clicked(0, 2); return true; }
            if ((array[2, 0] == array[2, 1]) && (array[2, 1] == num) && (array[2, 2] == 0)) { clicked(2, 2); return true; }
            if ((array[2, 0] == array[2, 2]) && (array[2, 2] == num) && (array[2, 1] == 0)) { clicked(2, 1); return true; }
            if ((array[2, 1] == array[2, 2]) && (array[2, 2] == num) && (array[2, 0] == 0)) { clicked(2, 0); return true; }
            return false;
        }
        ////////////////////////////////////////////////////////////////////

        // check all states when 2 cells pushed by non-PC player could lead to win
        private bool checkNonPCTwoCells(int num)
        {
            var tempNum = 10 / num;
            if ((array[0, 0] == array[0, 1]) && (array[0, 1] == tempNum) && (array[0, 2] == 0)) { clicked(0, 2); return true; }
            if ((array[0, 0] == array[0, 2]) && (array[0, 2] == tempNum) && (array[0, 1] == 0)) { clicked(0, 1); return true; }
            if ((array[0, 0] == array[1, 0]) && (array[1, 0] == tempNum) && (array[2, 0] == 0)) { clicked(2, 0); return true; }
            if ((array[0, 0] == array[1, 1]) && (array[1, 1] == tempNum) && (array[2, 2] == 0)) { clicked(2, 2); return true; }
            if ((array[0, 0] == array[2, 0]) && (array[2, 0] == tempNum) && (array[1, 0] == 0)) { clicked(1, 0); return true; }
            if ((array[0, 0] == array[2, 2]) && (array[2, 2] == tempNum) && (array[1, 1] == 0)) { clicked(1, 1); return true; }
            if ((array[0, 1] == array[0, 2]) && (array[0, 2] == tempNum) && (array[0, 0] == 0)) { clicked(0, 0); return true; }
            if ((array[0, 1] == array[1, 1]) && (array[1, 1] == tempNum) && (array[2, 1] == 0)) { clicked(2, 1); return true; }
            if ((array[0, 1] == array[2, 1]) && (array[2, 1] == tempNum) && (array[1, 1] == 0)) { clicked(1, 1); return true; }
            if ((array[0, 2] == array[1, 1]) && (array[1, 1] == tempNum) && (array[2, 0] == 0)) { clicked(2, 0); return true; }
            if ((array[0, 2] == array[1, 2]) && (array[1, 2] == tempNum) && (array[2, 2] == 0)) { clicked(2, 2); return true; }
            if ((array[0, 2] == array[2, 0]) && (array[2, 0] == tempNum) && (array[1, 1] == 0)) { clicked(1, 1); return true; }
            if ((array[0, 2] == array[2, 2]) && (array[2, 2] == tempNum) && (array[1, 2] == 0)) { clicked(1, 2); return true; }
            if ((array[1, 0] == array[1, 1]) && (array[1, 1] == tempNum) && (array[1, 2] == 0)) { clicked(1, 2); return true; }
            if ((array[1, 0] == array[1, 2]) && (array[1, 2] == tempNum) && (array[1, 1] == 0)) { clicked(1, 1); return true; }
            if ((array[1, 0] == array[2, 0]) && (array[2, 0] == tempNum) && (array[0, 0] == 0)) { clicked(0, 0); return true; }
            if ((array[1, 1] == array[1, 2]) && (array[1, 2] == tempNum) && (array[1, 0] == 0)) { clicked(1, 0); return true; }
            if ((array[1, 1] == array[2, 0]) && (array[2, 0] == tempNum) && (array[0, 2] == 0)) { clicked(0, 2); return true; }
            if ((array[1, 1] == array[2, 1]) && (array[2, 1] == tempNum) && (array[0, 1] == 0)) { clicked(0, 1); return true; }
            if ((array[1, 1] == array[2, 2]) && (array[2, 2] == tempNum) && (array[0, 0] == 0)) { clicked(0, 0); return true; }
            if ((array[1, 2] == array[2, 2]) && (array[2, 2] == tempNum) && (array[0, 2] == 0)) { clicked(0, 2); return true; }
            if ((array[2, 0] == array[2, 1]) && (array[2, 1] == tempNum) && (array[2, 2] == 0)) { clicked(2, 2); return true; }
            if ((array[2, 0] == array[2, 2]) && (array[2, 2] == tempNum) && (array[2, 1] == 0)) { clicked(2, 1); return true; }
            if ((array[2, 1] == array[2, 2]) && (array[2, 2] == tempNum) && (array[2, 0] == 0)) { clicked(2, 0); return true; }
            return false;
        }
        ////////////////////////////////////////////////////////////////////


        private void HandleClick(int row, int col)
        {

        }

        public MainWindow()
        {
            InitializeComponent();
            buttonBoard[0, 0] = Bt00;
            buttonBoard[0, 1] = Bt01;
            buttonBoard[0, 2] = Bt02;
            buttonBoard[1, 0] = Bt10;
            buttonBoard[1, 1] = Bt11;
            buttonBoard[1, 2] = Bt12;
            buttonBoard[2, 0] = Bt20;
            buttonBoard[2, 1] = Bt21;
            buttonBoard[2, 2] = Bt22;
            //resetGame();
        }


        private void Bt00_Click(object sender, RoutedEventArgs e)
        {
            clicked(0, 0);
        }

        private void Bt01_Click(object sender, RoutedEventArgs e)
        {
            clicked(0, 1);
        }

        private void Bt02_Click(object sender, RoutedEventArgs e)
        {
            clicked(0, 2);
        }

        private void Bt10_Click(object sender, RoutedEventArgs e)
        {
            clicked(1, 0);
        }

        private void Bt11_Click(object sender, RoutedEventArgs e)
        {
            clicked(1, 1);
        }

        private void Bt12_Click(object sender, RoutedEventArgs e)
        {
            clicked(1, 2);
        }

        private void Bt20_Click(object sender, RoutedEventArgs e)
        {
            clicked(2, 0);
        }

        private void Bt21_Click(object sender, RoutedEventArgs e)
        {
            clicked(2, 1);
        }

        private void Bt22_Click(object sender, RoutedEventArgs e)
        {
            clicked(2, 2);
        }

        private void btnStart_Click(object sender, RoutedEventArgs e)
        {
            firstPlayerMove = true;
            left_player.Background = Brushes.Red;
            right_player.Background = Brushes.Azure;
            gameEnd = false;
            winner = 0;
            if (firstGamerName.Text == "" ) firstGamerName.Text = "O player";
            firstGamerName.FontWeight = FontWeights.Bold;
            if (secondGamerName.Text == "") secondGamerName.Text = "X player";
            secondGamerName.FontWeight = FontWeights.Bold;

            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                {
                    array[i, j] = 0;
                    board[i, j] = CellState.Empty;
                    buttonBoard[i, j].Content = "";
                    Button buttonNumber = (Button)this.FindName("Bt" + i.ToString() + j.ToString());
                    buttonNumber.IsEnabled = true;
                }
            }

            if (oPCplayer && xPCplayer)
            {
                MessageBox.Show("Note. Both player use the same algorithm.");
            }
            if (oPCplayer)
            {
                leftPCplayer.IsEnabled = false;
                if (firstPlayerMove) { checkState(1); }
            }
            if (xPCplayer)
            {
                rightPCplayer.IsEnabled = false;
                if (!firstPlayerMove) { checkState(10); }
            }

        }

        private void leftPCplayer_Click(object sender, RoutedEventArgs e)
        {
            leftPCplayerFunction();
        }

        private void rightPCplayer_Click(object sender, RoutedEventArgs e)
        {
            rightPCplayerFunction();
        }

        private void btnExit_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
